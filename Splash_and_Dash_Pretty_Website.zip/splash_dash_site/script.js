const form=document.getElementById('bookingForm');
const message=document.getElementById('formMessage');
const dateInput=form.querySelector('input[type="date"]');
const today=new Date().toISOString().split('T')[0];
dateInput.min=today;
form.addEventListener('submit',e=>{e.preventDefault();const data=new FormData(form);message.textContent=`Thanks, ${data.get('name')}! Your ${data.get('package')} appointment request for ${data.get('date')} at ${data.get('time')} has been received.`;form.reset();dateInput.min=today;});
